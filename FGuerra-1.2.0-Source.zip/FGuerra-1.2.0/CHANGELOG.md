# FGuerra 1.2.0 — Reconectar e moderação

## Novidades
- `/guerra reconectar` — volta ao evento após desconectar (padrão: 5 minutos, `reconectar-minutos`)
- Regras: clan ainda vivo na guerra; no modo SETADO guarda o inventário do evento
- `/guerra puxar <nick>` (admin) — puxa qualquer jogador com clan
- `/guerra kick <nick>` (admin) — remove um jogador
- `/guerra kickall <tag>` (admin) — elimina o clan inteiro do evento
- Comandos proibidos valem para **todo o servidor** enquanto a guerra está ativa (staff com `fguerra.admin` ignora)
- Mensagem ao entrar no servidor se ainda for possível reconectar
