package com.fplugins.guerra;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.*;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

@SuppressWarnings("deprecation")
public class FGuerra extends JavaPlugin implements Listener {

    private static class DisconnectData {
        final String clanTag;
        final long time;
        final ItemStack[] eventInv;
        final ItemStack[] eventArmor;
        DisconnectData(String clan, long t, ItemStack[] inv, ItemStack[] armor) {
            this.clanTag = clan; this.time = t; this.eventInv = inv; this.eventArmor = armor;
        }
    }

    private File mapsFile; private FileConfiguration mapsData; private File kitFile;
    private final Set<UUID> participants = new HashSet<>();
    private final Set<UUID> alive = new HashSet<>();
    private final Map<UUID, ItemStack[]> savedInv = new HashMap<>();
    private final Map<UUID, ItemStack[]> savedArmor = new HashMap<>();
    private final Map<UUID, DisconnectData> disconnected = new HashMap<>();
    private final Map<UUID, Integer> killCount = new HashMap<>();
    private final Map<UUID, Integer> reconnectAttempts = new HashMap<>();
    private final Map<UUID, Integer> leaveCount = new HashMap<>();
    private long eventStartMillis = 0L;
    private boolean running, pvpEnabled, countdown;
    private String currentMap;
    private int pvpSecondsLeft;
    private BukkitTask pvpTask, autoTask, broadcastTask, reconnectCleanTask;
    private ItemStack[] eventKit, eventArmor;
    private Object scManager, fClansPlugin, vaultEconomy, fEconomyPlugin;
    private String clanProvider = "none", ecoProvider = "command";

    public void onEnable() {
        saveDefaultConfig();
        mapsFile = new File(getDataFolder(), "maps.yml");
        if (!mapsFile.exists()) try { getDataFolder().mkdirs(); mapsFile.createNewFile(); } catch (IOException ignored) {}
        mapsData = YamlConfiguration.loadConfiguration(mapsFile);
        kitFile = new File(getDataFolder(), "kit.yml");
        loadKit();
        hookProviders();
        Bukkit.getPluginManager().registerEvents(this, this);
        startAutoStartChecker();
        reconnectCleanTask = Bukkit.getScheduler().runTaskTimer(this, this::cleanExpiredReconnects, 20L * 30, 20L * 30);
        getLogger().info("FGuerra 1.3.0 | clan=" + clanProvider + " eco=" + ecoProvider);
    }

    public void onDisable() {
        if (running) forceStop(false);
        if (autoTask != null) autoTask.cancel();
        if (pvpTask != null) pvpTask.cancel();
        if (broadcastTask != null) broadcastTask.cancel();
        if (reconnectCleanTask != null) reconnectCleanTask.cancel();
    }

    private void hookProviders() {
        String pref = getConfig().getString("clan-provider", "auto").toLowerCase();
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("SimpleClans");
            if (pl != null && pl.isEnabled()) scManager = pl.getClass().getMethod("getClanManager").invoke(pl);
        } catch (Throwable t) { scManager = null; }
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("FClans");
            if (pl != null && pl.isEnabled()) fClansPlugin = pl;
        } catch (Throwable t) { fClansPlugin = null; }
        if (pref.equals("simpleclans") && scManager != null) clanProvider = "simpleclans";
        else if (pref.equals("fclans") && fClansPlugin != null) clanProvider = "fclans";
        else if (scManager != null) clanProvider = "simpleclans";
        else if (fClansPlugin != null) clanProvider = "fclans";
        else clanProvider = "none";

        String ep = getConfig().getString("economy-provider", "auto").toLowerCase();
        try {
            Class<?> econClass = Class.forName("net.milkbowl.vault.economy.Economy");
            Object reg = Bukkit.getServicesManager().getRegistration(econClass);
            if (reg != null) vaultEconomy = reg.getClass().getMethod("getProvider").invoke(reg);
        } catch (Throwable t) { vaultEconomy = null; }
        try {
            Plugin pl = Bukkit.getPluginManager().getPlugin("FEconomy");
            if (pl != null && pl.isEnabled()) fEconomyPlugin = pl;
        } catch (Throwable t) { fEconomyPlugin = null; }
        if (ep.equals("vault") && vaultEconomy != null) ecoProvider = "vault";
        else if (ep.equals("feconomy") && fEconomyPlugin != null) ecoProvider = "feconomy";
        else if (ep.equals("command")) ecoProvider = "command";
        else if (vaultEconomy != null) ecoProvider = "vault";
        else if (fEconomyPlugin != null) ecoProvider = "feconomy";
        else ecoProvider = "command";
    }

    private void saveMaps() { try { mapsData.save(mapsFile); } catch (IOException e) { e.printStackTrace(); } }
    private void loadKit() {
        if (!kitFile.exists()) return;
        FileConfiguration kc = YamlConfiguration.loadConfiguration(kitFile);
        List<?> contents = kc.getList("contents"); List<?> armor = kc.getList("armor");
        if (contents != null) { eventKit = new ItemStack[contents.size()]; for (int i=0;i<contents.size();i++) if (contents.get(i) instanceof ItemStack) eventKit[i]=(ItemStack)contents.get(i); }
        if (armor != null) { eventArmor = new ItemStack[armor.size()]; for (int i=0;i<armor.size();i++) if (armor.get(i) instanceof ItemStack) eventArmor[i]=(ItemStack)armor.get(i); }
    }
    private void saveKitToFile() {
        FileConfiguration kc = new YamlConfiguration(); kc.set("contents", eventKit); kc.set("armor", eventArmor);
        try { kc.save(kitFile); } catch (IOException e) { e.printStackTrace(); }
    }
    private String cor(String s) { return ChatColor.translateAlternateColorCodes('&', s==null?"":s); }
    private String prefix() { return cor(getConfig().getString("mensagens.prefixo", "&8[&cGuerra&8] &r")); }
    private void sendKey(Player p, String key) { p.sendMessage(prefix()+cor(getConfig().getString("mensagens."+key, key))); }
    private void sendKey(Player p, String key, String k, String v) { p.sendMessage(prefix()+cor(getConfig().getString("mensagens."+key, key).replace(k,v))); }
    private void broadcastList(String key, Map<String,String> reps) {
        List<String> lines = getConfig().getStringList("mensagens."+key);
        if (lines==null) return;
        for (String line : lines) {
            String out = line;
            if (reps!=null) for (Map.Entry<String,String> e: reps.entrySet()) out = out.replace(e.getKey(), e.getValue());
            Bukkit.broadcastMessage(prefix()+cor(out));
        }
    }

    public String getClanTag(Player p) {
        if (p == null) return null;
        if (fClansPlugin != null) {
            try {
                Object tag = fClansPlugin.getClass().getMethod("getClanTag", Player.class).invoke(fClansPlugin, p);
                if (tag != null) return String.valueOf(tag);
            } catch (Throwable ignored) {}
        }
        if (scManager != null) {
            try {
                Object cp = scManager.getClass().getMethod("getClanPlayer", Player.class).invoke(scManager, p);
                if (cp == null) return null;
                Object clan = cp.getClass().getMethod("getClan").invoke(cp);
                if (clan == null) return null;
                Object tag = clan.getClass().getMethod("getTag").invoke(clan);
                return tag == null ? null : String.valueOf(tag);
            } catch (Throwable t) {
                try {
                    Object cp = scManager.getClass().getMethod("getClanPlayer", String.class).invoke(scManager, p.getName());
                    if (cp == null) return null;
                    Object clan = cp.getClass().getMethod("getClan").invoke(cp);
                    if (clan == null) return null;
                    return String.valueOf(clan.getClass().getMethod("getTag").invoke(clan));
                } catch (Throwable t2) { return null; }
            }
        }
        return null;
    }

    private boolean sameClan(Player a, Player b) {
        String ta = getClanTag(a), tb = getClanTag(b);
        return ta != null && ta.equalsIgnoreCase(tb);
    }

    private long reconnectMillis() {
        return Math.max(1, getConfig().getInt("reconectar-minutos", 5)) * 60L * 1000L;
    }

    private void cleanExpiredReconnects() {
        if (!running) { disconnected.clear(); return; }
        long now = System.currentTimeMillis();
        long limit = reconnectMillis();
        Iterator<Map.Entry<UUID, DisconnectData>> it = disconnected.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, DisconnectData> e = it.next();
            if (now - e.getValue().time > limit) {
                it.remove();
                participants.remove(e.getKey());
                alive.remove(e.getKey());
                savedInv.remove(e.getKey());
                savedArmor.remove(e.getKey());
                checkWin();
            }
        }
    }

    private boolean isClanStillInWar(String clanTag) {
        if (clanTag == null) return false;
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && clanTag.equalsIgnoreCase(getClanTag(p))) return true;
        }
        for (DisconnectData d : disconnected.values()) {
            if (clanTag.equalsIgnoreCase(d.clanTag) && System.currentTimeMillis() - d.time <= reconnectMillis()) return true;
        }
        return false;
    }

    private void giveReward(String nick, double amount) {
        if ("vault".equals(ecoProvider) && vaultEconomy != null) {
            try { vaultEconomy.getClass().getMethod("depositPlayer", String.class, double.class).invoke(vaultEconomy, nick, amount); return; } catch (Throwable ignored) {}
        }
        if ("feconomy".equals(ecoProvider) && fEconomyPlugin != null) {
            try { fEconomyPlugin.getClass().getMethod("deposit", String.class, double.class).invoke(fEconomyPlugin, nick, amount); return; } catch (Throwable ignored) {}
        }
    }

    private void runRewards(String clan, List<String> nicks) {
        List<String> rewards = getConfig().getStringList("recompensas");
        if (rewards == null) rewards = Collections.emptyList();
        for (String nick : nicks) {
            if ("vault".equals(ecoProvider) || "feconomy".equals(ecoProvider)) {
                double amt = 100;
                for (String cmd : rewards) {
                    String[] parts = cmd.trim().split("\\s+");
                    for (int i = parts.length - 1; i >= 0; i--) {
                        try { amt = Double.parseDouble(parts[i]); break; } catch (Exception ignored) {}
                    }
                }
                giveReward(nick, amt);
            }
            for (String cmd : rewards) {
                String single = cmd.replace("%nicks%", nick).replace("%nick%", nick).replace("%clan%", clan);
                boolean isEco = single.toLowerCase().matches(".*\\beco\\b.*") || single.toLowerCase().contains("money give") || single.toLowerCase().contains("feconomy");
                if ("command".equals(ecoProvider) || !isEco) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), single);
                } else if ("command".equals(ecoProvider)) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), single);
                }
            }
        }
    }

    private Location getPoint(String map, String point) {
        String path = "maps." + map.toLowerCase() + "." + point.toLowerCase();
        if (!mapsData.contains(path + ".world")) return null;
        World w = Bukkit.getWorld(mapsData.getString(path + ".world"));
        if (w == null) return null;
        return new Location(w, mapsData.getDouble(path+".x"), mapsData.getDouble(path+".y"), mapsData.getDouble(path+".z"),
                (float)mapsData.getDouble(path+".yaw"), (float)mapsData.getDouble(path+".pitch"));
    }
    private void setPoint(String map, String point, Location loc) {
        String path = "maps." + map.toLowerCase() + "." + point.toLowerCase();
        mapsData.set(path+".world", loc.getWorld().getName());
        mapsData.set(path+".x", loc.getX()); mapsData.set(path+".y", loc.getY()); mapsData.set(path+".z", loc.getZ());
        mapsData.set(path+".yaw", loc.getYaw()); mapsData.set(path+".pitch", loc.getPitch());
        saveMaps();
    }
    private String kitMode() { return getConfig().getString("kit-mode", "SETADO").toUpperCase(); }
    private boolean hasForbiddenItems(Player p) {
        List<String> banned = getConfig().getStringList("itens-proibidos");
        if (banned == null || banned.isEmpty()) return false;
        for (ItemStack it : p.getInventory().getContents()) if (it != null && banned.contains(it.getType().name())) return true;
        for (ItemStack it : p.getInventory().getArmorContents()) if (it != null && banned.contains(it.getType().name())) return true;
        return false;
    }
    private void applyKit(Player p) {
        if ("PROPRIO".equals(kitMode())) {
            List<String> banned = getConfig().getStringList("itens-proibidos");
            if (banned != null) {
                ItemStack[] cont = p.getInventory().getContents();
                for (int i=0;i<cont.length;i++) if (cont[i]!=null && banned.contains(cont[i].getType().name())) cont[i]=null;
                p.getInventory().setContents(cont);
                ItemStack[] arm = p.getInventory().getArmorContents();
                for (int i=0;i<arm.length;i++) if (arm[i]!=null && banned.contains(arm[i].getType().name())) arm[i]=null;
                p.getInventory().setArmorContents(arm);
            }
            return;
        }
        p.getInventory().clear(); p.getInventory().setArmorContents(null);
        if (eventKit != null) for (ItemStack it : eventKit) if (it != null && it.getType() != Material.AIR) p.getInventory().addItem(it.clone());
        if (eventArmor != null) {
            ItemStack[] arm = new ItemStack[4];
            for (int i=0;i<Math.min(4,eventArmor.length);i++) if (eventArmor[i]!=null) arm[i]=eventArmor[i].clone();
            p.getInventory().setArmorContents(arm);
        }
    }
    private void savePlayerInv(Player p) {
        savedInv.put(p.getUniqueId(), cloneArr(p.getInventory().getContents()));
        savedArmor.put(p.getUniqueId(), cloneArr(p.getInventory().getArmorContents()));
    }
    private void restorePlayerInv(Player p) {
        ItemStack[] inv = savedInv.remove(p.getUniqueId());
        ItemStack[] arm = savedArmor.remove(p.getUniqueId());
        p.getInventory().clear();
        p.getInventory().setArmorContents(null);
        if (inv != null) p.getInventory().setContents(inv);
        if (arm != null) p.getInventory().setArmorContents(arm);
        p.updateInventory();
    }
    private ItemStack[] cloneArr(ItemStack[] in) {
        if (in==null) return null; ItemStack[] out=new ItemStack[in.length];
        for (int i=0;i<in.length;i++) out[i]=in[i]==null?null:in[i].clone(); return out;
    }
    private int countClans() {
        Set<String> tags = new HashSet<>();
        for (UUID id : participants) {
            Player p = Bukkit.getPlayer(id); if (p==null) continue;
            String tag = getClanTag(p); if (tag!=null) tags.add(tag.toLowerCase());
        }
        return tags.size();
    }
    private Map<String,Integer> aliveClans() {
        Map<String,Integer> map = new LinkedHashMap<>();
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id); if (p==null||!p.isOnline()) continue;
            String tag = getClanTag(p); if (tag==null) tag="?";
            map.put(tag, map.getOrDefault(tag,0)+1);
        }
        for (DisconnectData d : disconnected.values()) {
            if (System.currentTimeMillis() - d.time > reconnectMillis()) continue;
            String tag = d.clanTag == null ? "?" : d.clanTag;
            map.put(tag, map.getOrDefault(tag, 0) + 1);
        }
        return map;
    }
    private boolean canStart() {
        return participants.size() >= getConfig().getInt("min-players",4) && countClans() >= getConfig().getInt("min-clans",2);
    }

    private void beginCountdownBroadcast(final String map, final int totalSeconds) {
        countdown = true; currentMap = map;
        if (broadcastTask != null) broadcastTask.cancel();
        final int[] left = {totalSeconds};
        broadcastTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!countdown) { broadcastTask.cancel(); return; }
            if (left[0] <= 0) {
                broadcastTask.cancel();
                if (!canStart()) { broadcastList("guerra-insuficientes", null); participants.clear(); countdown=false; currentMap=null; return; }
                startWar(map, false); return;
            }
            if (left[0]%20==0 || left[0]<=10) {
                Map<String,String> r = new HashMap<>();
                r.put("%segundos%", String.valueOf(left[0]));
                r.put("%membros%", String.valueOf(participants.size()));
                r.put("%clans%", String.valueOf(countClans()));
                broadcastList("guerra-iniciando", r);
            }
            left[0]--;
        }, 0L, 20L);
    }

    private void startWar(String map, boolean force) {
        countdown = false;
        if (!force && !canStart()) { broadcastList("guerra-insuficientes", null); participants.clear(); currentMap=null; return; }
        currentMap = map; running = true; pvpEnabled = false; alive.clear(); alive.addAll(participants); disconnected.clear();
        killCount.clear(); eventStartMillis = System.currentTimeMillis();
        Location entrada = getPoint(map, "entrada");
        for (UUID id : new HashSet<>(participants)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) { participants.remove(id); alive.remove(id); continue; }
            savePlayerInv(p);
            if (entrada != null) p.teleport(entrada);
            applyKit(p);
            p.setGameMode(GameMode.SURVIVAL);
            try { p.setHealth(p.getMaxHealth()); } catch (Throwable t) { p.setHealth(20); }
            p.setFoodLevel(20);
        }
        int minutes = getConfig().getInt("tempo-pvp-minutos", 1);
        pvpSecondsLeft = Math.max(1, minutes) * 60;
        Map<String,String> r = new HashMap<>(); r.put("%segundos%", String.valueOf(pvpSecondsLeft));
        broadcastList(force ? "guerra-forcestart" : "guerra-iniciado", r);
        if (pvpTask != null) pvpTask.cancel();
        pvpTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!running) { pvpTask.cancel(); return; }
            pvpSecondsLeft--;
            if (pvpSecondsLeft <= 0) { pvpTask.cancel(); pvpEnabled = true; broadcastList("pvp-on", null); }
            else if (pvpSecondsLeft==10 || pvpSecondsLeft==5) Bukkit.broadcastMessage(prefix()+cor("&ePvP em &c"+pvpSecondsLeft+"s&e!"));
        }, 20L, 20L);
    }

    private void restoreAllAndTeleport() {
        Location saida = currentMap != null ? getPoint(currentMap, "saida") : null;
        Set<UUID> all = new HashSet<>(participants);
        all.addAll(savedInv.keySet());
        for (UUID id : all) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                restorePlayerInv(p);
                if (saida != null) p.teleport(saida);
            } else {
                savedInv.remove(id);
                savedArmor.remove(id);
            }
        }
    }

    private void forceStop(boolean admin) {
        if (pvpTask != null) pvpTask.cancel();
        if (broadcastTask != null) broadcastTask.cancel();
        countdown = false; running = false; pvpEnabled = false;
        restoreAllAndTeleport();
        participants.clear(); alive.clear(); disconnected.clear(); killCount.clear(); leaveCount.clear(); currentMap = null;
        if (admin) broadcastList("guerra-parar", null);
    }

    private void eliminatePlayer(UUID id, boolean teleportSaida) {
        alive.remove(id);
        participants.remove(id);
        disconnected.remove(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            restorePlayerInv(p);
            if (teleportSaida) {
                Location saida = currentMap != null ? getPoint(currentMap, "saida") : null;
                if (saida != null) p.teleport(saida);
            }
        } else {
            savedInv.remove(id); savedArmor.remove(id);
        }
    }

    private void checkWin() {
        if (!running) return;
        Map<String,Integer> clans = aliveClans();
        if (clans.size() > 1) return;
        if (clans.isEmpty()) {
            forceStop(false);
            Bukkit.broadcastMessage(prefix()+cor("&cNenhum clan sobreviveu."));
            return;
        }
        String winner = clans.keySet().iterator().next();
        List<String> nicks = new ArrayList<>();
        for (UUID id : new HashSet<>(alive)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) nicks.add(p.getName());
        }
        // MVP = mais kills
        String mvp = "-";
        int bestKills = -1;
        for (Map.Entry<UUID, Integer> e : killCount.entrySet()) {
            if (e.getValue() > bestKills) {
                bestKills = e.getValue();
                Player mp = Bukkit.getPlayer(e.getKey());
                mvp = mp != null ? mp.getName() + " (" + bestKills + ")" : e.getKey().toString().substring(0, 8) + " (" + bestKills + ")";
            }
        }
        java.time.LocalDate data = java.time.LocalDate.now(zoneId());
        String dataStr = data.getDayOfMonth() + "/" + data.getMonthValue() + "/" + data.getYear();
        Map<String,String> r = new HashMap<>();
        r.put("%clan%", winner);
        r.put("%tag%", winner);
        r.put("%nicks%", String.join(" ", nicks));
        r.put("%mvp%", mvp);
        r.put("%data%", dataStr);
        List<String> extra = getConfig().getStringList("mensagens.guerra-vitoria-extra");
        if (extra != null && !extra.isEmpty()) {
            for (String line : extra) {
                String out = line;
                for (Map.Entry<String,String> en : r.entrySet()) out = out.replace(en.getKey(), en.getValue());
                Bukkit.broadcastMessage(prefix() + cor(out));
            }
        } else {
            broadcastList("guerra-vitoria", r);
        }

        // Restaura inv ANTES das recompensas
        if (pvpTask != null) pvpTask.cancel();
        countdown = false;
        running = false;
        pvpEnabled = false;
        restoreAllAndTeleport();
        participants.clear();
        alive.clear();
        disconnected.clear();
        currentMap = null;

        runRewards(winner, nicks);
    }

    private ZoneId zoneId() {
        String f = getConfig().getString("horario-fuso","BR").toUpperCase();
        if (f.equals("PT")||f.equals("LISBOA")) return ZoneId.of("Europe/Lisbon");
        return ZoneId.of("America/Sao_Paulo");
    }
    private void startAutoStartChecker() {
        autoTask = Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            private String lastKey = "";
            public void run() {
                ConfigurationSection sec = getConfig().getConfigurationSection("autostart");
                if (sec == null) return;
                ZonedDateTime now = ZonedDateTime.now(zoneId());
                String hm = String.format("%02d:%02d", now.getHour(), now.getMinute());
                String key = now.toLocalDate()+" "+hm;
                if (key.equals(lastKey)) return;
                for (String map : sec.getKeys(false)) {
                    if (hm.equals(sec.getString(map,""))) {
                        lastKey = key;
                        if (!running && !countdown) beginCountdownBroadcast(map, 180);
                    }
                }
            }
        }, 20L, 20L*15);
    }

    private void openMenu(Player p) {
        String title = cor(getConfig().getString("mensagens.menu-title", "&8Guerra de clans"));
        Inventory inv = Bukkit.createInventory(null, 27, title);
        ItemStack enter = new ItemStack(Material.LIME_CONCRETE);
        ItemMeta em = enter.getItemMeta(); em.setDisplayName(cor("&aEntrar no evento"));
        em.setLore(Arrays.asList(cor("&7Clique para &a/guerra entrar"), cor("&8action:entrar")));
        enter.setItemMeta(em); inv.setItem(10, enter);
        ItemStack glass = new ItemStack(Material.GLASS);
        ItemMeta gm = glass.getItemMeta(); gm.setDisplayName(cor("&bIr para o camarote"));
        gm.setLore(Arrays.asList(cor("&7So se a guerra ja iniciou"), cor("&8action:camarote")));
        glass.setItemMeta(gm); inv.setItem(13, glass);
        ItemStack stand = new ItemStack(Material.ARMOR_STAND);
        ItemMeta sm = stand.getItemMeta(); sm.setDisplayName(cor("&eClans vivos"));
        List<String> sl = new ArrayList<>();
        if (running) {
            Map<String,Integer> ac = aliveClans();
            if (ac.isEmpty()) sl.add(cor("&7Nenhum"));
            else for (Map.Entry<String,Integer> e : ac.entrySet()) sl.add(cor("&f"+e.getKey()+" &7("+e.getValue()+")"));
        } else {
            sl.add(cor("&7Guerra nao iniciada"));
            sl.add(cor("&7Na fila: &f"+participants.size()));
            sl.add(cor("&7Clans: &f"+countClans()));
        }
        sl.add(cor("&8action:info")); sm.setLore(sl); stand.setItemMeta(sm); inv.setItem(16, stand);
        p.openInventory(inv);
    }

    private void doReconnect(Player p) {
        if (!running) { sendKey(p, "nao-correndo"); return; }
        DisconnectData data = disconnected.get(p.getUniqueId());
        if (data == null) { sendKey(p, "reconectar-fail"); return; }
        int maxLeaves = getConfig().getInt("max-saidas-reconectar", 3);
        if (leaveCount.getOrDefault(p.getUniqueId(), 0) >= maxLeaves) {
            sendKey(p, "reconectar-limite");
            disconnected.remove(p.getUniqueId());
            return;
        }
        long min = getConfig().getInt("reconectar-minutos", 5);
        if (System.currentTimeMillis() - data.time > reconnectMillis()) {
            disconnected.remove(p.getUniqueId());
            sendKey(p, "reconectar-fail-tempo", "%min%", String.valueOf(min));
            return;
        }
        if (!isClanStillInWar(data.clanTag)) {
            disconnected.remove(p.getUniqueId());
            sendKey(p, "reconectar-fail-clan");
            return;
        }
        String currentTag = getClanTag(p);
        if (currentTag == null || (data.clanTag != null && !data.clanTag.equalsIgnoreCase(currentTag))) {
            disconnected.remove(p.getUniqueId());
            sendKey(p, "reconectar-fail-clan");
            return;
        }
        disconnected.remove(p.getUniqueId());
        participants.add(p.getUniqueId());
        alive.add(p.getUniqueId());
        if (!savedInv.containsKey(p.getUniqueId())) {
            savePlayerInv(p);
        }
        Location entrada = currentMap != null ? getPoint(currentMap, "entrada") : null;
        if (entrada != null) p.teleport(entrada);
        if ("SETADO".equals(kitMode())) {
            p.getInventory().clear();
            p.getInventory().setArmorContents(null);
            if (data.eventInv != null) p.getInventory().setContents(cloneArr(data.eventInv));
            if (data.eventArmor != null) p.getInventory().setArmorContents(cloneArr(data.eventArmor));
            boolean empty = true;
            for (ItemStack it : p.getInventory().getContents()) if (it != null && it.getType() != Material.AIR) { empty = false; break; }
            if (empty) applyKit(p);
        } else {
            applyKit(p);
        }
        p.setGameMode(GameMode.SURVIVAL);
        p.updateInventory();
        sendKey(p, "reconectou");
    }

    private void pullPlayer(Player target) {
        if (!running) return;
        participants.add(target.getUniqueId());
        alive.add(target.getUniqueId());
        disconnected.remove(target.getUniqueId());
        savePlayerInv(target);
        Location entrada = currentMap != null ? getPoint(currentMap, "entrada") : null;
        if (entrada != null) target.teleport(entrada);
        applyKit(target);
        target.setGameMode(GameMode.SURVIVAL);
        try { target.setHealth(target.getMaxHealth()); } catch (Throwable t) { target.setHealth(20); }
        target.setFoodLevel(20);
        sendKey(target, "puxado");
    }

    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length < 1) {
            if (s instanceof Player && s.hasPermission("fguerra.menu")) { openMenu((Player)s); return true; }
            s.sendMessage(cor("&e/guerra entrar|sair|menu|reconectar|iniciar|parar|kick|kickall|puxar|...")); return true;
        }
        String sub = a[0].toLowerCase();
        if (sub.equals("menu")) { if (s instanceof Player) openMenu((Player)s); return true; }
        if (sub.equals("reconectar")) {
            if (!(s instanceof Player)) return true;
            doReconnect((Player)s); return true;
        }
        if (sub.equals("entrar")) {
            if (!(s instanceof Player)) return true;
            Player p = (Player)s;
            if (!p.hasPermission("fguerra.entrar")) { sendKey(p,"sem-perm"); return true; }
            if (running) { sendKey(p,"ja-correndo"); return true; }
            if (getClanTag(p)==null) { sendKey(p,"sem-clan"); return true; }
            if ("PROPRIO".equals(kitMode()) && hasForbiddenItems(p)) { sendKey(p,"inventario"); return true; }
            participants.add(p.getUniqueId());
            String map = currentMap!=null?currentMap:"-";
            Location entrada = currentMap!=null?getPoint(currentMap,"entrada"):null;
            if (entrada!=null) p.teleport(entrada);
            sendKey(p,"entrou","%mapa%",map); return true;
        }
        if (sub.equals("sair")) {
            if (!(s instanceof Player)) return true;
            Player p = (Player)s;
            if (running && (alive.contains(p.getUniqueId()) || participants.contains(p.getUniqueId()))) {
                leaveCount.put(p.getUniqueId(), leaveCount.getOrDefault(p.getUniqueId(), 0) + 1);
                eliminatePlayer(p.getUniqueId(), true);
                sendKey(p,"saiu"); checkWin(); return true;
            }
            participants.remove(p.getUniqueId());
            Location saida = currentMap!=null?getPoint(currentMap,"saida"):null;
            if (saida!=null) p.teleport(saida); sendKey(p,"saiu"); return true;
        }
        if (sub.equals("camarote")) {
            if (!(s instanceof Player)) return true;
            Player p = (Player)s;
            if (!running) { sendKey(p,"nao-correndo"); return true; }
            if (alive.contains(p.getUniqueId()) && !p.hasPermission("fguerra.admin")) {
                p.sendMessage(prefix()+cor("&cNao podes ir ao camarote enquanto estas vivo.")); return true;
            }
            Location cam = currentMap!=null?getPoint(currentMap,"camarote"):null;
            if (cam!=null) p.teleport(cam); sendKey(p,"camarote"); return true;
        }
        if (!s.hasPermission("fguerra.admin")) { if (s instanceof Player) sendKey((Player)s,"sem-perm"); return true; }

        if (sub.equals("puxar") && a.length >= 2) {
            if (!running) { s.sendMessage(prefix()+cor("&cA guerra nao esta a decorrer.")); return true; }
            Player t = Bukkit.getPlayerExact(a[1]); if (t == null) t = Bukkit.getPlayer(a[1]);
            if (t == null) { s.sendMessage(cor("&cJogador offline.")); return true; }
            if (getClanTag(t) == null) { s.sendMessage(cor("&cEsse jogador nao tem clan.")); return true; }
            pullPlayer(t);
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.puxar-ok","&aPuxaste %player%").replace("%player%", t.getName())));
            return true;
        }
        if (sub.equals("kick") && a.length >= 2) {
            Player t = Bukkit.getPlayerExact(a[1]); if (t == null) t = Bukkit.getPlayer(a[1]);
            if (t == null) { s.sendMessage(cor("&cJogador offline.")); return true; }
            UUID id = t.getUniqueId();
            if (!participants.contains(id) && !alive.contains(id) && !disconnected.containsKey(id)) {
                s.sendMessage(cor("&cNao esta na guerra.")); return true;
            }
            sendKey(t, "kick");
            eliminatePlayer(id, true);
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.kick-ok","&aKickaste %player%").replace("%player%", a[1])));
            checkWin();
            return true;
        }
        if (sub.equals("kickall") && a.length >= 2) {
            String tag = a[1];
            int count = 0;
            for (UUID id : new HashSet<>(participants)) {
                Player p = Bukkit.getPlayer(id);
                String pt = p != null ? getClanTag(p) : null;
                if (pt == null) {
                    DisconnectData d = disconnected.get(id);
                    if (d != null) pt = d.clanTag;
                }
                if (pt != null && pt.equalsIgnoreCase(tag)) {
                    if (p != null) sendKey(p, "kick");
                    eliminatePlayer(id, true);
                    count++;
                }
            }
            for (UUID id : new HashSet<>(disconnected.keySet())) {
                DisconnectData d = disconnected.get(id);
                if (d != null && d.clanTag != null && d.clanTag.equalsIgnoreCase(tag)) {
                    eliminatePlayer(id, false);
                    count++;
                }
            }
            if (count == 0) s.sendMessage(prefix()+cor(getConfig().getString("mensagens.kickall-fail","&cNenhum.")));
            else s.sendMessage(prefix()+cor(getConfig().getString("mensagens.kickall-ok","&aClan eliminado").replace("%clan%", tag)));
            checkWin();
            return true;
        }
        if (sub.equals("criar") && a.length>=2) {
            mapsData.set("maps."+a[1].toLowerCase()+".name", a[1]); saveMaps();
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.mapa-criado","").replace("%mapa%",a[1]))); return true;
        }
        if (sub.equals("set") && a.length>=3) {
            if (!(s instanceof Player)) return true;
            String map=a[1].toLowerCase(), point=a[2].toLowerCase();
            if (!point.equals("entrada")&&!point.equals("saida")&&!point.equals("camarote")) {
                s.sendMessage(cor("&e/guerra set <mapa> <Entrada|Saida|Camarote>")); return true;
            }
            setPoint(map, point, ((Player)s).getLocation());
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.set-ok","").replace("%ponto%",point).replace("%mapa%",map))); return true;
        }
        if (sub.equals("setarkit") && a.length >= 3) {
            if (!(s instanceof Player)) return true;
            Player p = (Player) s;
            String map = a[1].toLowerCase();
            String mode = a[2].toUpperCase().startsWith("P") ? "PROPRIO" : "SETADO";
            mapsData.set("maps." + map + ".kit-mode", mode);
            if (mode.equals("SETADO")) {
                // guarda items do inventario incluindo armadura para este mapa
                List<ItemStack> cont = new ArrayList<>();
                for (ItemStack it : p.getInventory().getContents()) cont.add(it == null ? null : it.clone());
                List<ItemStack> arm = new ArrayList<>();
                for (ItemStack it : p.getInventory().getArmorContents()) arm.add(it == null ? null : it.clone());
                // also save global event kit for compatibility
                eventKit = cloneArr(p.getInventory().getContents());
                eventArmor = cloneArr(p.getInventory().getArmorContents());
                saveKitToFile();
                mapsData.set("maps." + map + ".kit-saved", true);
            }
            saveMaps();
            getConfig().set("kit-mode", mode);
            saveConfig();
            s.sendMessage(prefix() + cor("&aKit do mapa &e" + map + " &adefinido como &e" + mode + "&a."));
            return true;
        }
        if (sub.equals("setarkit")) {
            s.sendMessage(cor("&e/guerra setarkit <mapa> <setado|proprio>"));
            return true;
        }
        if (sub.equals("setkit") && a.length >= 2) {
            // legado
            String mode = a[1].toUpperCase().startsWith("P") ? "PROPRIO" : "SETADO";
            getConfig().set("kit-mode", mode);
            saveConfig();
            s.sendMessage(prefix() + cor(getConfig().getString("mensagens.kit-mode", "").replace("%mode%", mode)));
            return true;
        }
        if (sub.contains("horario") && a.length>=2) {
            String f=a[1].toUpperCase(); if (!f.equals("BR")&&!f.equals("PT")) { s.sendMessage(cor("&eBR ou PT")); return true; }
            getConfig().set("horario-fuso", f); saveConfig();
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.fuso","").replace("%fuso%",f))); return true;
        }
        if (sub.equals("tempo") && a.length>=2) {
            int min; try { min=Integer.parseInt(a[1]); } catch(Exception ex){ s.sendMessage(cor("&cInvalido")); return true; }
            getConfig().set("tempo-pvp-minutos", Math.max(0,min)); saveConfig();
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.tempo","").replace("%min%",String.valueOf(min)))); return true;
        }
        if (sub.equals("autostart") && a.length>=3) {
            getConfig().set("autostart."+a[1].toLowerCase(), a[2]); saveConfig();
            s.sendMessage(prefix()+cor(getConfig().getString("mensagens.autostart","").replace("%mapa%",a[1]).replace("%hora%",a[2]))); return true;
        }
        if (sub.equals("iniciar") && a.length>=2) {
            if (running) { s.sendMessage(prefix()+cor("&cJa a decorrer.")); return true; }
            beginCountdownBroadcast(a[1].toLowerCase(), 60); return true;
        }
        if (sub.equals("forcestart")) {
            if (currentMap==null && a.length>=2) currentMap=a[1].toLowerCase();
            if (currentMap==null) { s.sendMessage(cor("&c/guerra forcestart <mapa>")); return true; }
            if (broadcastTask!=null) broadcastTask.cancel(); countdown=false; startWar(currentMap, true); return true;
        }
        if (sub.equals("parar")) {
            if (!running && !countdown) { s.sendMessage(prefix()+cor("&cNada a parar.")); return true; }
            forceStop(true); return true;
        }
        if (sub.equals("reload")) { reloadConfig(); hookProviders(); s.sendMessage(prefix()+cor("&aReload.")); return true; }
        s.sendMessage(prefix()+cor(getConfig().getString("mensagens.help-header", "&c&lAJUDA - FGUERRA")));
        List<String> helps = getConfig().getStringList("mensagens.help-lines");
        if (helps == null || helps.isEmpty()) {
            s.sendMessage(cor("&e/guerra entrar|sair|reconectar|menu|criar|set|iniciar|parar|kick|kickall|puxar"));
        } else {
            for (String h : helps) s.sendMessage(cor(h));
        }
        return true;
    }

    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        String title = ChatColor.stripColor(e.getView().getTitle());
        String expect = ChatColor.stripColor(cor(getConfig().getString("mensagens.menu-title","Guerra de clans")));
        if (title==null || !title.equalsIgnoreCase(expect)) return;
        e.setCancelled(true);
        ItemStack it = e.getCurrentItem();
        if (it==null||!it.hasItemMeta()||!it.getItemMeta().hasLore()) return;
        Player p = (Player)e.getWhoClicked();
        String action=null;
        for (String line : it.getItemMeta().getLore()) {
            String plain=ChatColor.stripColor(line);
            if (plain!=null && plain.startsWith("action:")) action=plain.substring(7);
        }
        if (action==null) return;
        p.closeInventory();
        if (action.equals("entrar")) Bukkit.dispatchCommand(p,"guerra entrar");
        else if (action.equals("camarote")) Bukkit.dispatchCommand(p,"guerra camarote");
    }

    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!running) return;
        if (!(e.getDamager() instanceof Player)||!(e.getEntity() instanceof Player)) return;
        Player d=(Player)e.getDamager(), v=(Player)e.getEntity();
        if (!participants.contains(d.getUniqueId())||!participants.contains(v.getUniqueId())) return;
        if (!pvpEnabled) { e.setCancelled(true); return; }
        if (sameClan(d,v)) e.setCancelled(true);
    }

    @EventHandler public void onDeath(PlayerDeathEvent e) {
        final Player p = e.getEntity();
        if (!running || !alive.contains(p.getUniqueId())) return;
        Player killer = p.getKiller();
        if (killer != null && participants.contains(killer.getUniqueId())) {
            int kk = killCount.getOrDefault(killer.getUniqueId(), 0) + 1;
            killCount.put(killer.getUniqueId(), kk);
            int vk = killCount.getOrDefault(p.getUniqueId(), 0);
            String msg = getConfig().getString("mensagens.kill-msg",
                "&c%killer%&7(&f%killer_kills%&7) matou &c%victim%&7(&f%victim_kills%&7).");
            msg = msg.replace("%killer%", killer.getName()).replace("%victim%", p.getName())
                .replace("%killer_kills%", String.valueOf(kk)).replace("%victim_kills%", String.valueOf(vk));
            Bukkit.broadcastMessage(prefix() + cor(msg));
        }
        String deadClan = getClanTag(p);
        alive.remove(p.getUniqueId());
        disconnected.remove(p.getUniqueId());
        // clan eliminado?
        if (deadClan != null && !isClanStillInWar(deadClan)) {
            Map<String,Integer> rest = aliveClans();
            String clansLeft = rest.isEmpty() ? "0" : String.join(", ", rest.keySet());
            String cm = getConfig().getString("mensagens.clan-eliminado",
                "&c%clan% &7foi eliminado da guerra! Clans restantes: &e%clans%");
            Bukkit.broadcastMessage(prefix() + cor(cm.replace("%clan%", deadClan).replace("%clans%", clansLeft)));
        }
        e.getDrops().clear(); e.setDroppedExp(0);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) {
                try { p.spigot().respawn(); } catch (Throwable ignored) {}
                Location cam = currentMap!=null?getPoint(currentMap,"camarote"):null;
                if (cam!=null) p.teleport(cam);
                restorePlayerInv(p);
                participants.remove(p.getUniqueId());
            }
        }, 2L);
        checkWin();
    }

    @EventHandler public void onRespawn(PlayerRespawnEvent e) {
        if (!running||!participants.contains(e.getPlayer().getUniqueId())) return;
        if (alive.contains(e.getPlayer().getUniqueId())) return;
        Location cam = currentMap!=null?getPoint(currentMap,"camarote"):null;
        if (cam!=null) e.setRespawnLocation(cam);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Player p = e.getPlayer();
        if (running && alive.contains(id)) {
            String tag = getClanTag(p);
            ItemStack[] eventInv = cloneArr(p.getInventory().getContents());
            ItemStack[] eventArmor = cloneArr(p.getInventory().getArmorContents());
            disconnected.put(id, new DisconnectData(tag, System.currentTimeMillis(), eventInv, eventArmor));
            int leaves = leaveCount.getOrDefault(id, 0) + 1;
            leaveCount.put(id, leaves);
            String cm = getConfig().getString("mensagens.caiu-evento",
                "&e%jogador% &7caiu do evento, ele possui &c5 minutos &7para usar &a/guerra reconectar&7.");
            Bukkit.broadcastMessage(prefix() + cor(cm.replace("%jogador%", p.getName())));
            alive.remove(id);
            ItemStack[] origInv = savedInv.get(id);
            ItemStack[] origArm = savedArmor.get(id);
            p.getInventory().clear();
            p.getInventory().setArmorContents(null);
            if (origInv != null) p.getInventory().setContents(cloneArr(origInv));
            if (origArm != null) p.getInventory().setArmorContents(cloneArr(origArm));
            return;
        }
        if (!running) {
            participants.remove(id);
            savedInv.remove(id);
            savedArmor.remove(id);
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        if (running && disconnected.containsKey(e.getPlayer().getUniqueId())) {
            DisconnectData d = disconnected.get(e.getPlayer().getUniqueId());
            if (System.currentTimeMillis() - d.time <= reconnectMillis()) {
                e.getPlayer().sendMessage(prefix()+cor("&ePodes usar &a/guerra reconectar &epara voltar ao evento."));
            }
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!running) return;
        Player p = e.getPlayer();
        if (p.hasPermission("fguerra.admin")) return;
        String msg = e.getMessage().toLowerCase();
        if (msg.startsWith("/guerra")) return;
        List<String> banned = getConfig().getStringList("comandos-proibidos");
        if (banned == null) return;
        for (String b : banned) {
            if (b == null) continue;
            String bb = b.toLowerCase().trim();
            if (msg.equals(bb) || msg.startsWith(bb + " ")) {
                e.setCancelled(true);
                sendKey(p, "comando-proibido");
                return;
            }
        }
    }

    @EventHandler public void onBreak(BlockBreakEvent e) {
        if (running && participants.contains(e.getPlayer().getUniqueId()) && !e.getPlayer().hasPermission("fguerra.admin")) e.setCancelled(true);
    }
    @EventHandler public void onPlace(BlockPlaceEvent e) {
        if (running && participants.contains(e.getPlayer().getUniqueId()) && !e.getPlayer().hasPermission("fguerra.admin")) e.setCancelled(true);
    }
}
