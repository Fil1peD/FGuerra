# FGuerra 1.2.1

Evento Guerra de Clans para Spigot/Paper 1.21.x

## Estrutura
```
src/main/java/com/fplugins/guerra/FGuerra.java
src/main/resources/plugin.yml
src/main/resources/config.yml
```

## Dependências (soft)
- SimpleClans ou FClans
- Vault ou FEconomy

## Compilar
```bash
javac -cp spigot-api.jar -d build src/main/java/com/fplugins/guerra/FGuerra.java
# empacotar build/ + resources num .jar
```

## Comandos principais
/guerra criar|set|setarkit|setkit|iniciar|forcestart|parar|entrar|sair|reconectar|puxar|kick|kickall|menu|autostart|tempo|sethorario|reload
