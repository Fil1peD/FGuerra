# FGuerra 1.3.1

Spigot/Paper 1.21.x — Guerra de Clans

## Estrutura
- src/main/java/com/fplugins/guerra/FGuerra.java
- src/main/resources/plugin.yml
- src/main/resources/config.yml
