# FGuerra 1.3.1

- Mensagens em PT-BR (ex: "Você precisa estar em um clan!")
- Base 1.3.0 (menu, reconectar, kick, MVP, help, setarkit por mapa)
