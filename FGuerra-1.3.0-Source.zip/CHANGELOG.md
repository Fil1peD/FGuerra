# FGuerra 1.3.0

- Menu: vidro +1 slot, armor stand +2 slots
- Help formatado AJUDA - FGUERRA
- /guerra setarkit <mapa> <setado|proprio>
- Mensagens a cada 20s no countdown
- Kill feed, clan eliminado, caiu + reconectar
- Limite 3 saídas para reconectar
- Vitória com tag, MVP e data
- Correção Que vença
