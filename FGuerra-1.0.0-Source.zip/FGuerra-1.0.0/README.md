# FGuerra 1.0.0

Spigot/Paper **1.21.x**

Ver **CHANGELOG.md** para as mudanças desta versão.
