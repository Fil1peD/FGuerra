# FGuerra 1.0.0 — Lançamento inicial

Primeira versão pública do evento **Guerra de Clans**.

## Novidades
- Sistema de mapas (`/guerra criar` e `/guerra set Entrada/Saida/Camarote`)
- Entrada na fila e início com countdown (`/guerra iniciar`, `/guerra forcestart`)
- Kit por inventário (`/guerra setarkit`) e modos SETADO / PRÓPRIO (`/guerra setkit`)
- PvP só após o tempo configurado (`/guerra tempo`)
- Vitória por último clan vivo + recompensas configuráveis
- Menu GUI (`/guerra` / `/guerra menu`)
- Integração com SimpleClans
- Auto-start por horário e fuso BR/PT
- Comandos e itens proibidos no config.yml
- Sem friendly fire no mesmo clan
- Bloqueio de quebra/colocação de blocos no evento
