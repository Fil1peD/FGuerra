# FGuerra 1.2.1 — Correções de inventário

## Correções
- Ao deslogar no meio da guerra: guarda o **kit do evento** para o reconectar e restaura o **inventário original** antes do save do servidor (os itens reais já não desaparecem)
- `/guerra reconectar` devolve o inventário **do evento**, não o inventário antigo
- No fim do evento (modo SETADO): restaura primeiro o inventário original e **só depois** aplica as recompensas (as recompensas deixam de ser apagadas pelo clear do kit)
