# FGuerra 1.2.1

Spigot/Paper **1.21.x**

Ver **CHANGELOG.md** para as mudanças desta versão.
